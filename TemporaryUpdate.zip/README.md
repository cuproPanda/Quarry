# Quarry

This mod adds a quarry for collecting rocks and resources in flat terrain.

![Preview](https://raw.githubusercontent.com/cuproPanda/QRY/master/About/Preview.PNG)
