﻿using System.Collections.Generic;

using Verse;

namespace Quarry {

  public class QuarryResourcesDef : Def {

    public Dictionary<ThingDef, int> additionalResources;
  }
}
